create
    definer = root@localhost procedure user(IN stu_name varchar(20))
BEGIN 
SELECT * from user where username = stu_name;
end;

