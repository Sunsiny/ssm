create definer = root@localhost view view_comment as
select `c`.`time` AS `时间`, `c`.`stars` AS `星星`, `c`.`content` AS `内容`, `u`.`realname` AS `用户`, `n`.`name` AS `保姆`
from `nanny`.`tb_comment` `c`
         join `nanny`.`tb_user` `u`
         join `nanny`.`tb_nanny` `n`
where ((`c`.`user_id` = `u`.`user_id`) and (`c`.`nanny_id` = `n`.`nanny_id`));

